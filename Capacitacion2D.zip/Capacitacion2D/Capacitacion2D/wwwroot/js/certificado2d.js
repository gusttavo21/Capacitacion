﻿window.certificado2D = {

    descargarCertificadoPdf: async function (folio) {
        try {
            const { jsPDF } = window.jspdf;

            const contenedor = document.getElementById("certificado-content");
            if (!contenedor) {
                console.error("No se encontró el contenedor del certificado.");
                return;
            }

            // Generar / regenerar QR
            const qrDiv = document.getElementById("qr-certificado");
            if (qrDiv) {
                qrDiv.innerHTML = "";
                new QRCode(qrDiv, {
                    text: folio || "CERTIFICADO 2D",
                    width: 96,
                    height: 96
                });
                // pequeño delay para asegurar que el QR se pinte
                await new Promise(r => setTimeout(r, 300));
            }

            // Captura del certificado como imagen
            const canvas = await html2canvas(contenedor, {
                scale: 2,
                useCORS: true
            });

            const imgData = canvas.toDataURL("image/png");
            const pdf = new jsPDF("landscape", "pt", "a4");

            const pageWidth = pdf.internal.pageSize.getWidth();
            const pageHeight = pdf.internal.pageSize.getHeight();

            const ratio = Math.min(pageWidth / canvas.width, pageHeight / canvas.height);
            const imgWidth = canvas.width * ratio;
            const imgHeight = canvas.height * ratio;

            const marginX = (pageWidth - imgWidth) / 2;
            const marginY = (pageHeight - imgHeight) / 2;

            pdf.addImage(imgData, "PNG", marginX, marginY, imgWidth, imgHeight);
            pdf.save(`Certificado_${folio || "2D"}.pdf`);
        } catch (e) {
            console.error("Error al generar el PDF del certificado:", e);
            alert("Ocurrió un error al generar el PDF.");
        }
    }

};
