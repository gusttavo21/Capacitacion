﻿namespace Capacitacion2D.Data
{
    public class RecuperacionPassword
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public string Token { get; set; } = string.Empty;
        public DateTime Expira { get; set; }
        public bool Usado { get; set; }
        public DateTime FechaCreacion { get; set; }

        public Usuario Usuario { get; set; } = null!;
    }
}

