﻿namespace Capacitacion2D.Data
{
    public class RespuestaEvaluacion
    {
        public int Id { get; set; }

        // Deben llamarse EXACTAMENTE igual que las columnas de SQL
        public int UsuarioId { get; set; }
        public int CursoId { get; set; }
        public int PreguntaEvaluacionId { get; set; }
        public int OpcionEvaluacionId { get; set; }

        public bool EsCorrecta { get; set; }
        public DateTime FechaRegistro { get; set; }

        // Navegaciones (opcionales, pero útiles)
        public Usuario Usuario { get; set; } = null!;
        public Curso Curso { get; set; } = null!;
        public PreguntaEvaluacion PreguntaEvaluacion { get; set; } = null!;
        public OpcionEvaluacion OpcionEvaluacion { get; set; } = null!;
    }
}
