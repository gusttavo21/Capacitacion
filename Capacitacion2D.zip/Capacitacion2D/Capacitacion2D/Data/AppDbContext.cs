﻿using Microsoft.EntityFrameworkCore;

namespace Capacitacion2D.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Empresa> Empresas => Set<Empresa>();
    public DbSet<RecuperacionPassword> RecuperacionPasswords => Set<RecuperacionPassword>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Curso> Cursos => Set<Curso>();
    public DbSet<UsuarioCurso> UsuariosCursos => Set<UsuarioCurso>();
    public DbSet<PreguntaEvaluacion> PreguntasEvaluacion => Set<PreguntaEvaluacion>();
    public DbSet<OpcionEvaluacion> OpcionesEvaluacion => Set<OpcionEvaluacion>();
    public DbSet<RespuestaEvaluacion> RespuestasEvaluacion => Set<RespuestaEvaluacion>();
    public DbSet<RecuperacionPassword> RecuperacionPassword => Set<RecuperacionPassword>();

 





    // … el resto de DbSet que ya tenías








    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<UsuarioCurso>(entity =>
        {
            // Clave primaria compuesta (no hay columna Id en la tabla)
            entity.HasKey(e => new { e.UsuarioId, e.CursoId });

            entity.ToTable("UsuariosCursos");

            entity.Property(e => e.ProgresoPorcentaje)
                  .HasDefaultValue(0);

            entity.Property(e => e.Certificado)
                  .HasDefaultValue(false);

            entity.Property(e => e.IntentosEvaluacion)
                  .HasDefaultValue(0);
            // Clave compuesta de UsuariosCursos
            modelBuilder.Entity<UsuarioCurso>()
                .HasKey(uc => new { uc.UsuarioId, uc.CursoId });
            // Relaciones (ajusta los nombres de las colecciones si difieren)
            entity.HasOne(e => e.Usuario)
                  .WithMany(u => u.UsuariosCursos)
                  .HasForeignKey(e => e.UsuarioId);

            entity.HasOne(e => e.Curso)
                  .WithMany(c => c.UsuariosCursos)
                  .HasForeignKey(e => e.CursoId);
        });


        modelBuilder.Entity<PreguntaEvaluacion>()
            .HasOne(p => p.Curso)
            .WithMany()
            .HasForeignKey(p => p.CursoId);

        modelBuilder.Entity<RecuperacionPassword>()
        .ToTable("RecuperacionPassword"); // singular EXACTO

        modelBuilder.Entity<OpcionEvaluacion>()
           .HasOne(o => o.Pregunta)
           .WithMany(p => p.Opciones)
           .HasForeignKey(o => o.PreguntaId);


    }
}
