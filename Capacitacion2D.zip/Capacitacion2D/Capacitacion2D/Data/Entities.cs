﻿using System;
using System.Collections.Generic;

namespace Capacitacion2D.Data;

public class Empresa
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public bool Activa { get; set; } = true;

    public ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();
    public ICollection<Curso> Cursos { get; set; } = new List<Curso>();
}

public class Usuario
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Contrasena { get; set; } = string.Empty;
    public string Rol { get; set; } = string.Empty; // AdminGlobal, AdminEmpresa, Usuario
    public int? EmpresaId { get; set; }
    public bool Activo { get; set; } = true;

    public Empresa? Empresa { get; set; }
    public ICollection<UsuarioCurso> UsuariosCursos { get; set; } = new List<UsuarioCurso>();

}

public class Curso
{
    public int Id { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string? Descripcion { get; set; }
    public int? EmpresaId { get; set; }
    public bool Activo { get; set; } = true;

    public Empresa? Empresa { get; set; }
    public ICollection<UsuarioCurso> UsuariosCursos { get; set; } = new List<UsuarioCurso>();
}

public class UsuarioCurso
{
    public int UsuarioId { get; set; }
    public int CursoId { get; set; }

    public int ProgresoPorcentaje { get; set; }
    public bool Certificado { get; set; }

    public int IntentosEvaluacion { get; set; } = 0;

    public int? NotaEvaluacion { get; set; }
    public DateTime? FechaEvaluacion { get; set; }

    public Usuario Usuario { get; set; }
    public Curso Curso { get; set; }
}


public class RecuperacionPasswords
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public string Token { get; set; } = string.Empty;
    public DateTime FechaSolicitud { get; set; }
    public bool Usado { get; set; }

    public Usuario Usuario { get; set; } = null!;
    public DateTime FechaCreacion { get; set; }

}
