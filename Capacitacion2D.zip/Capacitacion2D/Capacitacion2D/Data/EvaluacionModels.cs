﻿namespace Capacitacion2D.Data
{
    public class PreguntaEvaluacion
    {
        public int Id { get; set; }
        public int CursoId { get; set; }
        public Curso? Curso { get; set; }
        public string Texto { get; set; } = string.Empty;

        public ICollection<OpcionEvaluacion> Opciones { get; set; } = new List<OpcionEvaluacion>();
    }

    public class OpcionEvaluacion
    {
        public int Id { get; set; }

        // Debe coincidir con el nombre de la columna en SQL: PreguntaId
        public int PreguntaId { get; set; }

        public PreguntaEvaluacion? Pregunta { get; set; }
        public string Texto { get; set; } = string.Empty;
        public bool EsCorrecta { get; set; }
    }


}
