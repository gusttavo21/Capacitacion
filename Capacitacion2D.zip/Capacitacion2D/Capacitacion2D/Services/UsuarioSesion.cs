﻿namespace Capacitacion2D.Services;

public class UsuarioSesion
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Rol { get; set; } = string.Empty;
    public int? EmpresaId { get; set; }
}
