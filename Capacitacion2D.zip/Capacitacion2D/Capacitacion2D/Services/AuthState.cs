﻿namespace Capacitacion2D.Services;

public class AuthState
{
    public UsuarioSesion? UsuarioActual { get; private set; }
    public UsuarioSesion? UsuarioPendiente { get; private set; }

    public bool EstaAutenticado => UsuarioActual != null;
    public string RolActual => UsuarioActual?.Rol ?? string.Empty;

    public void EstablecerPendiente(UsuarioSesion usuario)
    {
        UsuarioPendiente = usuario;
    }

    public void ConfirmarCodigo()
    {
        if (UsuarioPendiente != null)
        {
            UsuarioActual = UsuarioPendiente;
            UsuarioPendiente = null;
        }
    }

    public void CerrarSesion()
    {
        UsuarioActual = null;
        UsuarioPendiente = null;
    }
}
